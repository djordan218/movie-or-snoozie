# API: http://www.omdbapi.com/
API_KEY = '188d3aee'